package com.example.gumpuwnompojava_port;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {

    private static final String SAMOGLOSKI = "aąeęiouóy";

    private final List<String> historia = new ArrayList<>();

    private final int TLO = Color.rgb(15, 17, 28);
    private final int PANEL = Color.rgb(27, 30, 46);
    private final int MAGENTA = Color.rgb(225, 95, 255);
    private final int CYAN = Color.rgb(75, 220, 255);
    private final int ZIELONY = Color.rgb(100, 235, 155);
    private final int BIALY = Color.rgb(240, 242, 250);
    private final int SZARY = Color.rgb(160, 168, 190);

    private LinearLayout glownyUklad;
    private LinearLayout zawartosc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        pokazMenu();
    }

    private void przygotujEkran(String podtytul) {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(TLO);

        glownyUklad = new LinearLayout(this);
        glownyUklad.setOrientation(LinearLayout.VERTICAL);
        glownyUklad.setPadding(dp(20), dp(18), dp(20), dp(24));
        glownyUklad.setGravity(Gravity.CENTER_HORIZONTAL);

        scroll.addView(glownyUklad);
        setContentView(scroll);

        TextView naglowek = new TextView(this);
        naglowek.setText("JĘMPĘZYMPYK");
        naglowek.setTextColor(MAGENTA);
        naglowek.setTextSize(27);
        naglowek.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        naglowek.setGravity(Gravity.CENTER);
        naglowek.setPadding(0, dp(20), 0, dp(8));
        glownyUklad.addView(naglowek, szerokoscPelna());

        TextView opis = new TextView(this);
        opis.setText("ULTIMATE LANGUAGE TRANSLATOR");
        opis.setTextColor(CYAN);
        opis.setTextSize(12);
        opis.setGravity(Gravity.CENTER);
        opis.setPadding(0, 0, 0, dp(8));
        glownyUklad.addView(opis, szerokoscPelna());

        TextView sekcja = new TextView(this);
        sekcja.setText(podtytul);
        sekcja.setTextColor(SZARY);
        sekcja.setTextSize(14);
        sekcja.setGravity(Gravity.CENTER);
        sekcja.setPadding(0, 0, 0, dp(24));
        glownyUklad.addView(sekcja, szerokoscPelna());

        zawartosc = new LinearLayout(this);
        zawartosc.setOrientation(LinearLayout.VERTICAL);
        glownyUklad.addView(zawartosc, szerokoscPelna());
    }

    private LinearLayout.LayoutParams szerokoscPelna() {
        return new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
    }

    private int dp(int wartosc) {
        return (int) (wartosc * getResources()
                .getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable tloZaokraglone(int kolor) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(kolor);
        drawable.setCornerRadius(dp(14));
        return drawable;
    }

    private TextView tekst(String tresc, int kolor, int rozmiar) {
        TextView view = new TextView(this);
        view.setText(tresc);
        view.setTextColor(kolor);
        view.setTextSize(rozmiar);
        view.setPadding(dp(4), dp(8), dp(4), dp(8));
        return view;
    }

    private void dodajPrzycisk(String nazwa, Runnable akcja) {
        Button button = new Button(this);
        button.setText(nazwa);
        button.setTextColor(BIALY);
        button.setTextSize(15);
        button.setAllCaps(false);
        button.setBackground(tloZaokraglone(PANEL));
        button.setPadding(dp(12), dp(10), dp(12), dp(10));

        LinearLayout.LayoutParams params = szerokoscPelna();
        params.bottomMargin = dp(12);

        zawartosc.addView(button, params);
        button.setOnClickListener(v -> akcja.run());
    }

    private void pokazMenu() {
        przygotujEkran("TWÓJ TŁUMACZ JĘZYKOWY");

        dodajPrzycisk("1.  Polski → JĘMPĘZYMPYK",
                () -> pokazTlumacz(true));

        dodajPrzycisk("2.  JĘMPĘZYMPYK → Polski",
                () -> pokazTlumacz(false));

        dodajPrzycisk("3.  Historia tłumaczeń",
                this::pokazHistorie);

        dodajPrzycisk("4.  Informacje",
                this::pokazInformacje);

        dodajPrzycisk("0.  Wyjście", this::finish);

        TextView stopka = tekst(
                "LINGUA  •  VERSION 1.1",
                SZARY, 12);
        stopka.setGravity(Gravity.CENTER);
        stopka.setPadding(0, dp(22), 0, dp(8));
        zawartosc.addView(stopka, szerokoscPelna());
    }

    private boolean czySamogloska(char znak) {
        return SAMOGLOSKI.indexOf(
                Character.toLowerCase(znak)) >= 0;
    }

    private String tlumaczNaLingua(String tekst) {
        StringBuilder wynik = new StringBuilder();

        for (int i = 0; i < tekst.length(); i++) {
            char znak = tekst.charAt(i);
            wynik.append(znak);

            if (czySamogloska(znak)) {
                wynik.append("mp");
                wynik.append(znak);
            }
        }

        return wynik.toString();
    }

    private String tlumaczNaPolski(String tekst) {
        StringBuilder wynik = new StringBuilder();

        for (int i = 0; i < tekst.length(); i++) {
            char znak = tekst.charAt(i);
            wynik.append(znak);

            if (czySamogloska(znak)
                    && i + 3 < tekst.length()
                    && tekst.charAt(i + 1) == 'm'
                    && tekst.charAt(i + 2) == 'p'
                    && Character.toLowerCase(tekst.charAt(i + 3))
                    == Character.toLowerCase(znak)) {

                i += 3;
            }
        }

        return wynik.toString();
    }

    private void pokazTlumacz(boolean naLingua) {
        String tryb = naLingua
                ? "POLSKI → JĘMPĘZYMPYK"
                : "JĘMPĘZYMPYK → POLSKI";

        przygotujEkran(tryb);

        TextView etykieta = tekst(
                "Wpisz tekst do przetłumaczenia:",
                BIALY, 15);
        zawartosc.addView(etykieta, szerokoscPelna());

        EditText poleTekstowe = new EditText(this);
        poleTekstowe.setHint("Tutaj wpisz tekst...");
        poleTekstowe.setHintTextColor(SZARY);
        poleTekstowe.setTextColor(BIALY);
        poleTekstowe.setTextSize(16);
        poleTekstowe.setGravity(
                Gravity.TOP | Gravity.START);
        poleTekstowe.setMinLines(4);
        poleTekstowe.setPadding(
                dp(14), dp(12), dp(14), dp(12));
        poleTekstowe.setBackground(tloZaokraglone(PANEL));

        zawartosc.addView(
                poleTekstowe, szerokoscPelna());

        TextView etykietaWyniku = tekst(
                "WYNIK TŁUMACZENIA",
                ZIELONY, 14);
        etykietaWyniku.setTypeface(
                Typeface.DEFAULT, Typeface.BOLD);

        LinearLayout.LayoutParams wynikParams =
                szerokoscPelna();
        wynikParams.topMargin = dp(18);

        zawartosc.addView(etykietaWyniku, wynikParams);

        TextView wynikTekst = tekst(
                "Tutaj pojawi się tłumaczenie.",
                BIALY, 16);
        wynikTekst.setBackground(tloZaokraglone(PANEL));
        wynikTekst.setPadding(
                dp(14), dp(16), dp(14), dp(16));
        wynikTekst.setTextIsSelectable(true);

        zawartosc.addView(
                wynikTekst, szerokoscPelna());

        dodajPrzycisk("TŁUMACZ", () -> {
            String wejscie =
                    poleTekstowe.getText().toString();

            if (wejscie.trim().isEmpty()) {
                Toast.makeText(
                        this,
                        "Wpisz tekst do tłumaczenia.",
                        Toast.LENGTH_SHORT
                ).show();
                return;
            }

            String wynik = naLingua
                    ? tlumaczNaLingua(wejscie)
                    : tlumaczNaPolski(wejscie);

            wynikTekst.setText(wynik);

            historia.add(
                    (naLingua
                            ? "PL > JĘMPĘZYMPYK: "
                            : "JĘMPĘZYMPYK > PL: ")
                            + wejscie + " => " + wynik);
        });

        dodajPrzycisk("WYCZYŚĆ", () -> {
            poleTekstowe.setText("");
            wynikTekst.setText(
                    "Tutaj pojawi się tłumaczenie.");
        });

        dodajPrzycisk("POWRÓT DO MENU",
                this::pokazMenu);
    }

    private void pokazHistorie() {
        przygotujEkran("HISTORIA TŁUMACZEŃ");

        if (historia.isEmpty()) {
            zawartosc.addView(
                    tekst("Brak tłumaczeń.",
                            SZARY, 16),
                    szerokoscPelna());
        } else {
            for (int i = historia.size() - 1;
                 i >= 0; i--) {

                TextView wpis = tekst(
                        "› " + historia.get(i),
                        CYAN, 14);

                wpis.setBackground(
                        tloZaokraglone(PANEL));
                wpis.setPadding(
                        dp(12), dp(12), dp(12), dp(12));

                LinearLayout.LayoutParams params =
                        szerokoscPelna();
                params.bottomMargin = dp(10);

                zawartosc.addView(wpis, params);
            }

            dodajPrzycisk("WYCZYŚĆ HISTORIĘ", () -> {
                historia.clear();
                pokazHistorie();
            });
        }

        dodajPrzycisk("POWRÓT DO MENU",
                this::pokazMenu);
    }

    private void pokazInformacje() {
        przygotujEkran("O PROJEKCIE");

        dodajInformacje("Nazwa", "JĘMPĘZYMPYK AAA");
        dodajInformacje("Wersja", "1.1");
        dodajInformacje("Technologia", "Java / Android");
        dodajInformacje("Biblioteki", "Android SDK");

        TextView regula = tekst(
                "ZASADA TŁUMACZENIA",
                ZIELONY, 16);
        regula.setTypeface(
                Typeface.DEFAULT, Typeface.BOLD);
        zawartosc.addView(regula, szerokoscPelna());

        zawartosc.addView(
                tekst("Samogłoski: a ą e ę i o u ó y",
                        BIALY, 14),
                szerokoscPelna());

        zawartosc.addView(
                tekst("Każda samogłoska jest uzupełniana "
                                + "o ciąg „mp” i powtórzoną "
                                + "samogłoskę.",
                        SZARY, 14),
                szerokoscPelna());

        zawartosc.addView(
                tekst("Przykład: kot → kompot",
                        CYAN, 16),
                szerokoscPelna());

        dodajPrzycisk("POWRÓT DO MENU",
                this::pokazMenu);
    }

    private void dodajInformacje(
            String nazwa, String wartosc) {

        TextView view = tekst(
                nazwa + ": " + wartosc,
                BIALY, 15);

        zawartosc.addView(view, szerokoscPelna());
    }
}